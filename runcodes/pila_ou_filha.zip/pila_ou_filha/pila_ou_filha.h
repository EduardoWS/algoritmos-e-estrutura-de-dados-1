#ifndef PILAOUFILHA_H
#define PILAOUFILHA_H

#define PILHA 1
#define FILA 2
#define INDEFINIDO 3
#define IMPOSSIVEL 4

int pilaOuFilha();

#endif